﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HugsLib;
using RimWorld;

namespace RunandHide
{
    public class RunandHideBase : ModBase
    {
        public override string ModIdentifier
        {
            get
            {
                return "RunandHide";
            }
        }
    }
}
